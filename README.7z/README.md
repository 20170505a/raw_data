# raw_data
Raw data for practice data analysis 


数据文件说明

| File name| description|reference|
| ------------- |:-------------:| -------------:| 
| data_szq_201|成年女子的红细胞数| 孙振球.徐勇勇 (2014). 医学统计学.第4版, 人民卫生出版社.例2-1|
| data002|       |   
| data003|       |  
| data003|       |   
| data004|    |   


	
